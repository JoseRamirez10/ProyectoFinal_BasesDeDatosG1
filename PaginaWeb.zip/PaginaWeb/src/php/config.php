<?php
// Datos para acceder a la base de datos
// Modificar los datos de acuerdo a su usuario y contraseña en postgres
// Respetar el espacio al final de los valores
$server = "host=localhost ";
$username = "user=jozfama ";
$password = "password= ";
$dbname = "dbname=restaurant3 ";
$post = $server . $dbname . $username . $password;
?>
